# RPStatus Updater

A World of Warcraft addon updater for RPStatus, designed specifically for Ascension WoW players.

## Installation

1. Download the latest version of `RPStatus-Updater.exe` from our [releases page](https://github.com/codexkeeper/RPStatus/releases) [not yet but soon]
2. When running the program for the first time, you may see these security warnings:

### Windows SmartScreen Warning
- You'll see a message "Windows protected your PC"
- Click "More info"
- Then click "Run anyway"

### User Account Control (UAC) Dialog
- You'll see a security warning showing "Unknown Publisher"
- This is normal for our self-signed certificate
- Click "Yes" to proceed

## Security Verification

You can verify the authenticity of the downloaded file:

1. Open Command Prompt as administrator
2. Navigate to the download folder
3. Run: `certutil -hashfile RPStatus-Updater.exe SHA256`
4. Compare the output with this hash:
```
a84d85735c5a1dd994b38108da4470d60e25fdddc9651fa59b9142b80ed5a1ec
```
If the hashes match, the file is authentic and hasn't been tampered with.

## Usage

1. Start the program from anywhere on your computer
2. Select your WoW AddOns folder when prompted
   - Usually located at: `[WoW Installation]/Interface/AddOns`
3. Click "Check and Update" to update RPStatus

## Features

- Automatic updates for RPStatus addon
- Simple one-click update process
- Backs up existing files before updating
- Verifies file integrity after download
- Minimizes to system tray for convenience

## Common Issues

1. "Folder not found" error
   - Make sure you select the correct AddOns folder
   - The path should end with `Interface/AddOns`

2. Update fails
   - Check your internet connection
   - Ensure WoW is not running during update
   - Try running the updater as administrator

## Technical Details

- The updater only modifies files in your WoW AddOns folder
- No system files are modified
- Updates are downloaded directly from our GitHub repository
- Full source code available at: https://github.com/codexkeeper/RPStatus

## Source Code & Contributing

This is an open-source project. You can:
- View the source code at: https://github.com/codexkeeper/RPStatus
- Build it yourself from source
- Submit issues and feature requests
- Contribute to development

## Support

If you encounter any issues:
1. Check the common issues section above
2. Visit our [GitHub issues page](https://github.com/codexkeeper/RPStatus/issues)
3. Create a new issue if your problem isn't listed

## License

This project is licensed under the GNU General Public License v3.0 (GPL-3.0). This means you can:
- Use the software for any purpose
- Change the software to suit your needs
- Share the software with anyone
- Share the changes you make

For the full license text, see [LICENSE](https://github.com/codexkeeper/RPStatus/blob/main/LICENSE) or visit: https://www.gnu.org/licenses/gpl-3.0.en.html

## Credits

Credits
Created by Ultimini from Random Encounters for the Ascension WoW community.
Visit: https://github.com/codexkeeper/RPStatus